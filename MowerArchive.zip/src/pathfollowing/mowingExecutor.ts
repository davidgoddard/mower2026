import { PathPoint } from "./pathFollowerApi.js";
import { ContinuousPathFollower } from "./continuousPathFollower.js";
import { buildMowingPlan, type MowingBoundaryReference, type MowingInitialEntryPlan, type MowingPlan } from "./mowingPlanner.js";
import type { MowingResumeContinuation, MowingResumeOperation, MowingResumeState, MowingResumeStage } from "./mowingResumeStore.js";
import { buildPerimeterJoinPlan, buildPerimeterPathPointsFromPlan, buildPerimeterPathPointsFromPlanAndPose, buildPerimeterPathPointsFromPose, buildPerimeterFollowPlan } from "./pathVerification.js";
import { RecentTargetSink } from "./segmentedBoundaryExecutor.js";
import { DriveController } from "../control/driveController.js";
import { TurnController } from "../control/turnController.js";
import { PoseFusion } from "../sensing/poseFusion.js";
import { LoggerScope } from "../logging/types.js";
import { systemStop } from "../control/systemStop.js";
import { createPosition } from "../geometry/positionTypes.js";
import { headingDifference, unwrapRelativeAngle, createInternalHeading } from "../geometry/headingTypes.js";
import type { PathFollowingParameters } from "../config/pathFollowingConfig.js";
import { DEFAULT_PATH_FOLLOWING_PARAMETERS } from "../config/pathFollowingConfig.js";

export type MowingPhase =
  | "idle"
  | "approaching_area_perimeter"
  | "approaching_strip"
  | "tracing_boundary"
  | "mowing_strip"
  | "following_connector"
  | "complete"
  | "stopped"
  | "error";

export interface MowingStatus {
  readonly phase: MowingPhase;
  readonly currentStripIndex: number;
  readonly totalStrips: number;
  readonly tracedBoundaryCount: number;
  readonly error?: string;
}

export interface MowingExecutorOptions {
  readonly areaName?: string;
  readonly plan: MowingPlan;
  readonly initialEntryPlan?: MowingInitialEntryPlan;
  readonly areaPoints: ReadonlyArray<PathPoint>;
  readonly obstaclePointsArray: ReadonlyArray<ReadonlyArray<PathPoint>>;
  readonly driveController: DriveController;
  readonly turnController: TurnController;
  readonly poseFusion: PoseFusion;
  readonly continuousPathFollower: ContinuousPathFollower;
  readonly logger: LoggerScope;
  readonly parameters?: PathFollowingParameters;
  /**
   * Optional sink for recording boundary targets the segmented executor has
   * just completed. Wired through to perimeter traces and inter-strip
   * connectors so the retry manager can reverse-retrace recent targets when
   * a high-current obstruction interrupts a mowing run.
   */
  readonly recentTargetSink?: RecentTargetSink;
  readonly updateRecoveryCheckpoint?: (waypoints: PathPoint[]) => void;
  readonly updateResumeState?: (state: MowingResumeState | null) => void;
  readonly resumeState?: MowingResumeState | null;
}

interface AreaStartAnchorPlan {
  readonly entryPlan: MowingInitialEntryPlan;
  readonly preferredStartPoint: { xMeters: number; yMeters: number };
}

const AREA_ESCAPE_STOP_DISTANCE_METERS = 0.15;
const AREA_ESCAPE_CHECK_INTERVAL_MS = 100;
const MOWING_TARGET_REACHED_TOLERANCE_METERS = 0.1;
const PERIMETER_JOIN_START_DISTANCE_METERS = 0.5;
const PREFERRED_BOUNDARY_POINT_TOLERANCE_METERS = 0.05;

export class MowingExecutor {
  private plan: MowingPlan;
  private readonly areaName: string;
  private readonly initialEntryPlan: MowingInitialEntryPlan | null;
  private readonly areaPoints: ReadonlyArray<PathPoint>;
  private readonly obstaclePointsArray: ReadonlyArray<ReadonlyArray<PathPoint>>;
  private readonly driveController: DriveController;
  private readonly turnController: TurnController;
  private readonly poseFusion: PoseFusion;
  private readonly continuousPathFollower: ContinuousPathFollower;
  private readonly logger: LoggerScope;
  private readonly parameters: PathFollowingParameters;
  private readonly standoff: number;
  private readonly recentTargetSink: RecentTargetSink | undefined;
  private readonly updateRecoveryCheckpoint: ((waypoints: PathPoint[]) => void) | undefined;
  private readonly updateResumeState: ((state: MowingResumeState | null) => void) | undefined;
  private readonly resumeState: MowingResumeState | null;

  private phase: MowingPhase = "idle";
  private currentStripIndex: number = 0;
  private tracedBoundaries: Set<string> = new Set();
  private stopRequested: boolean = false;
  private areaEscapeMonitor: NodeJS.Timeout | null = null;
  private outsideAreaViolationMessage: string | null = null;
  private selectedAreaStartAnchor: AreaStartAnchorPlan | null = null;

  constructor(options: MowingExecutorOptions) {
    this.areaName = options.areaName ?? "Unknown area";
    this.plan = options.plan;
    this.initialEntryPlan = options.initialEntryPlan ?? null;
    this.areaPoints = options.areaPoints;
    this.obstaclePointsArray = options.obstaclePointsArray;
    this.driveController = options.driveController;
    this.turnController = options.turnController;
    this.poseFusion = options.poseFusion;
    this.continuousPathFollower = options.continuousPathFollower;
    this.logger = options.logger;
    this.parameters = options.parameters ?? DEFAULT_PATH_FOLLOWING_PARAMETERS;
    this.standoff = this.parameters.mowingStandoffMeters;
    this.recentTargetSink = options.recentTargetSink;
    this.updateRecoveryCheckpoint = options.updateRecoveryCheckpoint;
    this.updateResumeState = options.updateResumeState;
    this.resumeState = options.resumeState ?? null;
  }

  getStatus(): MowingStatus {
    return {
      phase: this.phase,
      currentStripIndex: this.currentStripIndex,
      totalStrips: this.plan.strips.length,
      tracedBoundaryCount: this.tracedBoundaries.size,
    };
  }

  stop(): void {
    this.stopRequested = true;
  }

  async execute(): Promise<MowingStatus> {
    this.stopRequested = false;
    this.tracedBoundaries = this.resumeState
      ? new Set(this.resumeState.tracedBoundaryKeys)
      : new Set();
    this.outsideAreaViolationMessage = null;
    this.selectedAreaStartAnchor = null;
    this.stopAreaEscapeMonitor();
    this.logger.info("mowing.execute.start", { stripCount: this.plan.strips.length });

    try {
      if (this.resumeState) {
        return await this.executeResumeFlow();
      }

      this.prepareAreaStartAnchorPlan();
      const initialEntryStatus = await this.executeInitialEntry();
      if (initialEntryStatus) {
        return initialEntryStatus;
      }

      if (!this.selectedAreaStartAnchor) {
        this.reanchorPlanToCurrentPose();
      } else {
        this.currentStripIndex = 0;
      }
      this.startAreaEscapeMonitor();
      const outsideAreaStatus = this.buildOutsideAreaStatus();
      if (outsideAreaStatus) {
        return outsideAreaStatus;
      }

      return await this.runStripSequence(0, "strip_approach");
    } catch (error) {
      const message = error instanceof Error ? error.message : String(error);
      this.logger.error("mowing.execute.error", { error: message });
      this.phase = "error";
      return { ...this.getStatus(), error: message };
    } finally {
      this.stopAreaEscapeMonitor();
    }
  }

  private async executeInitialEntry(): Promise<MowingStatus | null> {
    const entryPlan = this.selectedAreaStartAnchor?.entryPlan ?? this.initialEntryPlan;
    if (!entryPlan) {
      return null;
    }
    if (this.isStopped()) {
      const outsideAreaStatus = this.buildOutsideAreaStatus();
      if (outsideAreaStatus) {
        return outsideAreaStatus;
      }
      this.phase = "stopped";
      return this.getStatus();
    }

    if (!pointInPolygon(
      entryPlan.approachTarget.xMeters,
      entryPlan.approachTarget.yMeters,
      this.areaPoints,
    )) {
      const insideApproachTarget = movePointInsideArea(
        entryPlan.entryPoint,
        entryPlan.approachTarget,
        this.areaPoints,
        this.standoff,
      );
      this.logger.info("mowing.initial_entry.adjusted_inside_area", {
        originalApproachX: entryPlan.approachTarget.xMeters,
        originalApproachY: entryPlan.approachTarget.yMeters,
        adjustedApproachX: insideApproachTarget.x,
        adjustedApproachY: insideApproachTarget.y,
      });
      return this.executeInitialEntryDriveAndTrace(entryPlan, insideApproachTarget);
    }

    return this.executeInitialEntryDriveAndTrace(entryPlan, entryPlan.approachTarget);
  }

  private async executeInitialEntryDriveAndTrace(
    entryPlan: MowingInitialEntryPlan,
    approachTarget: { xMeters: number; yMeters: number } | { x: number; y: number },
  ): Promise<MowingStatus | null> {
    this.phase = "approaching_area_perimeter";
    this.currentStripIndex = 0;
    this.logger.info("mowing.initial_entry.start", {
      segmentIndex: entryPlan.segmentIndex,
      entryX: entryPlan.entryPoint.xMeters,
      entryY: entryPlan.entryPoint.yMeters,
      approachX: "xMeters" in approachTarget ? approachTarget.xMeters : approachTarget.x,
      approachY: "yMeters" in approachTarget ? approachTarget.yMeters : approachTarget.y,
      distanceMeters: entryPlan.distanceMeters,
    });

    const approachX = "xMeters" in approachTarget ? approachTarget.xMeters : approachTarget.x;
    const approachY = "yMeters" in approachTarget ? approachTarget.yMeters : approachTarget.y;
    this.persistResumeOperation({
      kind: "drive",
      phase: "approaching_area_perimeter",
      stripIndex: 0,
      targetX: approachX,
      targetY: approachY,
      errorCode: "initial_entry_failed",
      continuation: { stage: "initial_boundary_trace", stripIndex: 0 },
    });
    if (!this.isNearCurrentPose(approachX, approachY)) {
      const approachResult = await this.driveController.executeDrive({
        targetPosition: createPosition(approachX, approachY),
        learningEnabled: true,
      });
      if (approachResult.status !== "success") {
        if (approachResult.status === "stopped") {
          const outsideAreaStatus = this.buildOutsideAreaStatus();
          if (outsideAreaStatus) {
            return outsideAreaStatus;
          }
          this.phase = "stopped";
          return this.getStatus();
        }
        this.phase = "error";
        return { ...this.getStatus(), error: `initial_entry_failed:${approachResult.status}` };
      }
    }

    if (this.isStopped()) {
      const outsideAreaStatus = this.buildOutsideAreaStatus();
      if (outsideAreaStatus) {
        return outsideAreaStatus;
      }
      this.phase = "stopped";
      return this.getStatus();
    }

    const traceResult = await this.traceBoundary("area", entryPlan.entryPoint, {
      stripIndex: 0,
      continuation: { stage: "strip_approach", stripIndex: 0 },
      markBoundaryTraced: "area",
    });
    if (!traceResult) {
      return this.getStatus();
    }

    this.tracedBoundaries.add("area");
    this.logger.info("mowing.initial_entry.done", {
      tracedBoundary: "area",
      segmentIndex: entryPlan.segmentIndex,
    });
    return null;
  }

  private async executeResumeFlow(): Promise<MowingStatus> {
    const resumeState = this.resumeState;
    if (!resumeState) {
      return this.getStatus();
    }

    this.currentStripIndex = resumeState.currentStripIndex;
    let continuation = await this.executeResumeOperation(resumeState.activeOperation);
    if (!continuation) {
      return this.getStatus();
    }
    if (continuation.stage === "initial_boundary_trace") {
      const entryPlan = resumeState.initialEntryPlan;
      if (!entryPlan) {
        this.phase = "error";
        return { ...this.getStatus(), error: "resume_initial_entry_plan_missing" };
      }
      const traceResult = await this.traceBoundary("area", entryPlan.entryPoint, {
        stripIndex: 0,
        continuation: { stage: "strip_approach", stripIndex: 0 },
        markBoundaryTraced: "area",
      });
      if (!traceResult) {
        return this.getStatus();
      }
      this.tracedBoundaries.add("area");
      continuation = { stage: "strip_approach", stripIndex: 0 };
    }
    if (continuation.stage === "complete") {
      return this.completeMowing();
    }

    if (continuation.stage !== "initial_entry_approach" && continuation.stage !== "initial_boundary_trace") {
      this.startAreaEscapeMonitor();
      const outsideAreaStatus = this.buildOutsideAreaStatus();
      if (outsideAreaStatus) {
        return outsideAreaStatus;
      }
    }

    return this.runStripSequence(continuation.stripIndex, continuation.stage);
  }

  private async runStripSequence(startIndex: number, startStage: MowingResumeStage): Promise<MowingStatus> {
    let stage = startStage;

    for (let index = startIndex; index < this.plan.strips.length; index += 1) {
      if (this.isStopped()) {
        const stoppedOutsideAreaStatus = this.buildOutsideAreaStatus();
        if (stoppedOutsideAreaStatus) {
          return stoppedOutsideAreaStatus;
        }
        this.phase = "stopped";
        return this.getStatus();
      }

      this.currentStripIndex = index;
      const strip = this.plan.strips[index];
      const stripStart = strip.traversalReversed ? strip.end : strip.start;
      const stripEnd = strip.traversalReversed ? strip.start : strip.end;
      const dir = normalise({
        x: stripEnd.xMeters - stripStart.xMeters,
        y: stripEnd.yMeters - stripStart.yMeters,
      });

      const entryStandoff = offsetPoint(stripStart, dir, this.standoff);
      const exitStandoff = offsetPoint(stripEnd, dir, -this.standoff);
      const startBoundaryKey = this.boundaryKeyFromReference(
        strip.traversalReversed ? strip.endBoundary : strip.startBoundary,
      );
      const endBoundaryKey = this.boundaryKeyFromReference(
        strip.traversalReversed ? strip.startBoundary : strip.endBoundary,
      );
      const isLastStrip = index === this.plan.strips.length - 1;

      if (stage === "strip_approach") {
        this.phase = "approaching_strip";
        this.persistResumeOperation({
          kind: "drive",
          phase: "approaching_strip",
          stripIndex: index,
          targetX: entryStandoff.x,
          targetY: entryStandoff.y,
          errorCode: "approach_failed",
          continuation: {
            stage: this.tracedBoundaries.has(startBoundaryKey) ? "strip_turn" : "start_boundary_trace",
            stripIndex: index,
          },
        });
        if (!this.isNearCurrentPose(entryStandoff.x, entryStandoff.y)) {
          const approachResult = await this.driveController.executeDrive({
            targetPosition: createPosition(entryStandoff.x, entryStandoff.y),
            learningEnabled: true,
          });
          if (approachResult.status !== "success") {
            if (approachResult.status === "stopped") {
              this.phase = "stopped";
              return this.getStatus();
            }
            this.phase = "error";
            return { ...this.getStatus(), error: `approach_failed:${approachResult.status}` };
          }
        }
        stage = this.tracedBoundaries.has(startBoundaryKey) ? "strip_turn" : "start_boundary_trace";
      }

      if (stage === "start_boundary_trace") {
        if (!this.tracedBoundaries.has(startBoundaryKey)) {
          const traceResult = await this.traceBoundary(startBoundaryKey, stripStart, {
            stripIndex: index,
            continuation: { stage: "strip_turn", stripIndex: index },
            markBoundaryTraced: startBoundaryKey,
          });
          if (!traceResult) {
            return this.getStatus();
          }
          this.tracedBoundaries.add(startBoundaryKey);
        }
        stage = "strip_turn";
      }

      if (this.isStopped()) {
        this.phase = "stopped";
        return this.getStatus();
      }

      if (stage === "strip_turn") {
        const stripHeading = Math.atan2(dir.y, dir.x) * (180 / Math.PI);
        this.persistResumeOperation({
          kind: "turn",
          phase: "mowing_strip",
          stripIndex: index,
          targetHeadingDeg: stripHeading,
          continuation: { stage: "strip_drive", stripIndex: index },
        });
        await this.turnToHeading(stripHeading);
        stage = "strip_drive";
      }

      if (this.isStopped()) {
        this.phase = "stopped";
        return this.getStatus();
      }

      if (stage === "strip_drive") {
        this.phase = "mowing_strip";
        this.persistResumeOperation({
          kind: "drive",
          phase: "mowing_strip",
          stripIndex: index,
          targetX: exitStandoff.x,
          targetY: exitStandoff.y,
          errorCode: "strip_drive_failed",
          continuation: {
            stage: !this.tracedBoundaries.has(endBoundaryKey)
              ? "end_boundary_trace"
              : (isLastStrip ? "complete" : "connector_follow"),
            stripIndex: index,
          },
        });
        if (!this.isNearCurrentPose(exitStandoff.x, exitStandoff.y)) {
          const stripResult = await this.driveController.executeDrive({
            targetPosition: createPosition(exitStandoff.x, exitStandoff.y),
            learningEnabled: true,
          });
          if (stripResult.status !== "success") {
            if (stripResult.status === "stopped") {
              this.phase = "stopped";
              return this.getStatus();
            }
            this.phase = "error";
            return { ...this.getStatus(), error: `strip_drive_failed:${stripResult.status}` };
          }
        }
        stage = !this.tracedBoundaries.has(endBoundaryKey)
          ? "end_boundary_trace"
          : (isLastStrip ? "complete" : "connector_follow");
      }

      if (stage === "end_boundary_trace") {
        if (!this.tracedBoundaries.has(endBoundaryKey)) {
          const continuation: MowingResumeContinuation = isLastStrip
            ? { stage: "complete", stripIndex: index }
            : { stage: "connector_follow", stripIndex: index };
          const traceResult = await this.traceBoundary(endBoundaryKey, stripEnd, {
            stripIndex: index,
            continuation,
            markBoundaryTraced: endBoundaryKey,
          });
          if (!traceResult) {
            return this.getStatus();
          }
          this.tracedBoundaries.add(endBoundaryKey);
        }
        stage = isLastStrip ? "complete" : "connector_follow";
      }

      if (this.isStopped()) {
        this.phase = "stopped";
        return this.getStatus();
      }

      if (stage === "complete") {
        return this.completeMowing();
      }

      if (stage === "connector_follow" && !isLastStrip) {
        const nextStrip = this.plan.strips[index + 1];
        const connector = this.plan.connectors[index];
        const nextStripStart = nextStrip.traversalReversed ? nextStrip.end : nextStrip.start;
        const nextStripEnd = nextStrip.traversalReversed ? nextStrip.start : nextStrip.end;
        const nextDir = normalise({
          x: nextStripEnd.xMeters - nextStripStart.xMeters,
          y: nextStripEnd.yMeters - nextStripStart.yMeters,
        });
        const nextEntryStandoff = offsetPoint(nextStripStart, nextDir, this.standoff);
        const transitionContinuation = { stage: "strip_approach" as const, stripIndex: index + 1 };
        const transitionResult = this.shouldUseDirectLaneTransfer(nextEntryStandoff.x, nextEntryStandoff.y)
          ? await this.followDirectLaneTransfer(nextEntryStandoff.x, nextEntryStandoff.y, index, transitionContinuation)
          : connector && connector.length >= 2
            ? await this.followConnector(connector, index, transitionContinuation)
            : { completed: true as const, reason: "reached_end" as const };
        if (transitionResult) {
          this.phase = "following_connector";
          if (!transitionResult.completed) {
            if (transitionResult.reason === "user_stopped") {
              this.phase = "stopped";
              return this.getStatus();
            }
            this.phase = "error";
            return { ...this.getStatus(), error: `connector_failed:${transitionResult.reason}` };
          }
        }
      }

      stage = "strip_approach";
    }

    return this.completeMowing();
  }

  private async executeResumeOperation(operation: MowingResumeOperation): Promise<MowingResumeContinuation | null> {
    this.currentStripIndex = operation.stripIndex;

    if (operation.kind === "drive") {
      this.phase = operation.phase;
      if (!this.isNearCurrentPose(operation.targetX, operation.targetY)) {
        const result = await this.driveController.executeDrive({
          targetPosition: createPosition(operation.targetX, operation.targetY),
          learningEnabled: true,
        });
        if (result.status !== "success") {
          if (result.status === "stopped") {
            this.phase = "stopped";
            return null;
          }
          this.phase = "error";
          return null;
        }
      }
      return operation.continuation;
    }

    if (operation.kind === "turn") {
      this.phase = operation.phase;
      await this.turnToHeading(operation.targetHeadingDeg);
      if (this.isStopped()) {
        this.phase = "stopped";
        return null;
      }
      return operation.continuation;
    }

    this.phase = operation.phase;
    this.updateRecoveryCheckpoint?.(operation.pathPoints);
    const result = await this.continuousPathFollower.executePath([...operation.pathPoints], {
      parameters: this.parameters,
      ...operation.followOptions,
    });
    if (!result.completed) {
      if (result.reason === "user_stopped") {
        this.phase = "stopped";
        return null;
      }
      this.phase = "error";
      return null;
    }
    if (operation.markBoundaryTraced) {
      this.tracedBoundaries.add(operation.markBoundaryTraced);
    }
    return operation.continuation;
  }

  private completeMowing(): MowingStatus {
    this.phase = "complete";
    this.clearResumeState();
    this.logger.info("mowing.execute.complete", { strips: this.plan.strips.length, tracedBoundaries: this.tracedBoundaries.size });
    return this.getStatus();
  }

  private persistResumeOperation(operation: MowingResumeOperation): void {
    this.updateResumeState?.({
      version: 1,
      areaName: this.areaName,
      savedAt: Date.now(),
      currentStripIndex: operation.stripIndex,
      totalStrips: this.plan.strips.length,
      tracedBoundaryKeys: [...this.tracedBoundaries],
      plan: this.plan,
      areaPoints: [...this.areaPoints],
      obstaclePointsArray: this.obstaclePointsArray.map((points) => [...points]),
      initialEntryPlan: this.selectedAreaStartAnchor?.entryPlan ?? this.initialEntryPlan,
      activeOperation: operation,
    });
  }

  private clearResumeState(): void {
    this.updateResumeState?.(null);
  }

  private async traceBoundary(
    boundaryKey: string,
    nearPoint: PathPoint,
    resumeMeta: {
      stripIndex: number;
      continuation: MowingResumeContinuation;
      markBoundaryTraced?: string;
    },
  ): Promise<boolean> {
    this.phase = "tracing_boundary";
    this.logger.info("mowing.trace_boundary.start", {
      boundary: boundaryKey,
      nearX: nearPoint.xMeters,
      nearY: nearPoint.yMeters,
    });

    const boundaryPoints = this.getBoundaryPoints(boundaryKey);
    if (boundaryPoints.length < 3) {
      this.logger.warn("mowing.trace_boundary.too_short", { boundary: boundaryKey });
      return true;
    }

    const currentPose = this.poseFusion.getCurrentPose();
    const forcedInitialAreaPlan = this.buildForcedInitialAreaTracePlan(boundaryKey, boundaryPoints, currentPose);
    const tracingBoundaryPoints = forcedInitialAreaPlan?.boundaryPoints ?? boundaryPoints;
    const joinPlan = forcedInitialAreaPlan?.plan ?? buildPerimeterJoinPlan(tracingBoundaryPoints, currentPose, this.parameters);
    if (!joinPlan) {
      this.logger.warn("mowing.trace_boundary.no_join_plan", { boundary: boundaryKey });
      return true;
    }

    if (forcedInitialAreaPlan) {
      this.updateRecoveryCheckpoint?.(forcedInitialAreaPlan.orderedLoopPoints);
      this.logger.info("mowing.trace_boundary.forced_anchor", {
        boundary: boundaryKey,
        anchorX: forcedInitialAreaPlan.anchorPoint.xMeters,
        anchorY: forcedInitialAreaPlan.anchorPoint.yMeters,
        pathDirection: joinPlan.pathDirection,
      });
    }

    const preTurnPath = forcedInitialAreaPlan
      ? buildPerimeterPathPointsFromPlanAndPose(
        tracingBoundaryPoints,
        currentPose,
        joinPlan,
        this.parameters,
        PERIMETER_JOIN_START_DISTANCE_METERS,
      )
      : buildPerimeterPathPointsFromPose(
        tracingBoundaryPoints,
        currentPose,
        joinPlan.pathDirection,
        this.parameters,
        PERIMETER_JOIN_START_DISTANCE_METERS,
      );
    if (preTurnPath.length < 2) {
      this.logger.warn("mowing.trace_boundary.no_preturn_path", {
        boundary: boundaryKey,
        pathDirection: joinPlan.pathDirection,
      });
      return true;
    }

    const joinLeadTarget = preTurnPath[1];
    const joinLeadHeading = createInternalHeading(
      Math.atan2(
        joinLeadTarget.yMeters - currentPose.position.yMeters,
        joinLeadTarget.xMeters - currentPose.position.xMeters,
      ) * (180 / Math.PI),
    );
    const turnAngle = headingDifference(currentPose.heading, joinLeadHeading);
    if (Math.abs(unwrapRelativeAngle(turnAngle)) > this.parameters.turnAlignmentThresholdDeg) {
      const turnResult = await this.turnController.executeTurn({
        targetAngle: turnAngle,
        direction: unwrapRelativeAngle(turnAngle) >= 0 ? "ccw" : "cw",
        learningEnabled: true,
      });
      if (turnResult.status !== "success") {
        if (turnResult.status === "stopped") {
          this.phase = "stopped";
          return false;
        }
      }
    }

    if (this.isStopped()) {
      this.phase = "stopped";
      return false;
    }

    const postTurnPose = this.poseFusion.getCurrentPose();
    const followPlan = forcedInitialAreaPlan
      ? joinPlan
      : buildPerimeterFollowPlan(
        tracingBoundaryPoints,
        postTurnPose,
        joinPlan.pathDirection,
        this.parameters,
      );
    if (!followPlan) {
      this.logger.warn("mowing.trace_boundary.no_follow_plan", {
        boundary: boundaryKey,
        pathDirection: joinPlan.pathDirection,
      });
      return true;
    }

    const loopPoints = forcedInitialAreaPlan
      ? buildPerimeterPathPointsFromPlanAndPose(
        tracingBoundaryPoints,
        postTurnPose,
        followPlan,
        this.parameters,
        PERIMETER_JOIN_START_DISTANCE_METERS,
      )
      : buildPerimeterPathPointsFromPose(
        tracingBoundaryPoints,
        postTurnPose,
        followPlan.pathDirection,
        this.parameters,
        PERIMETER_JOIN_START_DISTANCE_METERS,
      );
    if (loopPoints.length < 2) {
      return true;
    }

    this.persistResumeOperation({
      kind: "follow_path",
      phase: "tracing_boundary",
      stripIndex: resumeMeta.stripIndex,
      pathPoints: [...loopPoints],
      followOptions: {
        preserveFirstTargetAtPose: true,
        loopPath: false,
        strictOrderedProgress: true,
        minimumSpeed: 0.68,
        pivotIfInnerWheelBelow: 0.25,
      },
      errorCode: "boundary_trace_failed",
      continuation: resumeMeta.continuation,
      markBoundaryTraced: resumeMeta.markBoundaryTraced,
    });
    const followResult = await this.continuousPathFollower.executePath([...loopPoints], {
      parameters: this.parameters,
      preserveFirstTargetAtPose: true,
      loopPath: false,
      strictOrderedProgress: true,
      minimumSpeed: 0.68,
      pivotIfInnerWheelBelow: 0.25,
    });
    if (!followResult.completed) {
      if (followResult.reason === "user_stopped") {
        this.phase = "stopped";
        return false;
      }
      this.phase = "error";
      this.logger.warn("mowing.trace_boundary.failed", {
        boundary: boundaryKey,
        reason: followResult.reason === "obstruction" ? "error" : followResult.reason,
        error: followResult.error ?? (followResult.reason === "obstruction"
          ? "perimeter_follow_obstruction"
          : "perimeter_follow_failed"),
      });
      return false;
    }

    this.logger.info("mowing.trace_boundary.done", { boundary: boundaryKey });
    return true;
  }

  private async followConnector(
    connector: ReadonlyArray<PathPoint>,
    stripIndex: number,
    continuation: MowingResumeContinuation,
  ): Promise<{
    readonly completed: boolean;
    readonly reason: "reached_end" | "user_stopped" | "error";
    readonly error?: string;
  }> {
    if (connector.length < 2) {
      return { completed: true, reason: "reached_end" };
    }

    if (connector.length === 2) {
      const target = connector[connector.length - 1];
      this.persistResumeOperation({
        kind: "drive",
        phase: "following_connector",
        stripIndex,
        targetX: target.xMeters,
        targetY: target.yMeters,
        errorCode: "connector_failed",
        continuation,
      });
      if (this.isNearCurrentPose(target.xMeters, target.yMeters)) {
        return { completed: true, reason: "reached_end" };
      }
      const driveResult = await this.driveController.executeDrive({
        targetPosition: createPosition(target.xMeters, target.yMeters),
        learningEnabled: true,
      });
      if (driveResult.status === "success") {
        return { completed: true, reason: "reached_end" };
      }
      return {
        completed: false,
        reason: driveResult.status === "stopped" ? "user_stopped" : "error",
        error: driveResult.errorMessage,
      };
    }

    this.persistResumeOperation({
      kind: "follow_path",
      phase: "following_connector",
      stripIndex,
      pathPoints: [...connector],
      followOptions: {
        loopPath: false,
        strictOrderedProgress: true,
      },
      errorCode: "connector_failed",
      continuation,
    });
    const followResult = await this.continuousPathFollower.executePath(
      [...connector],
      {
        parameters: this.parameters,
        loopPath: false,
        strictOrderedProgress: true,
      },
    );
    if (followResult.completed) {
      return { completed: true, reason: "reached_end" };
    }
    return {
      completed: false,
      reason: followResult.reason === "user_stopped" ? "user_stopped" : "error",
      error: followResult.error,
    };
  }

  private async turnToHeading(targetHeadingDeg: number): Promise<void> {
    const currentPose = this.poseFusion.getCurrentPose();
    const targetHeading = createInternalHeading(targetHeadingDeg);
    const turnAngle = headingDifference(currentPose.heading, targetHeading);
    if (Math.abs(unwrapRelativeAngle(turnAngle)) <= this.parameters.turnAlignmentThresholdDeg) {
      return;
    }
    await this.turnController.executeTurn({
      targetAngle: turnAngle,
      direction: unwrapRelativeAngle(turnAngle) >= 0 ? "ccw" : "cw",
      learningEnabled: true,
    });
  }

  private boundaryKeyFromReference(boundary: MowingBoundaryReference): string {
    return boundary.kind === "area" ? "area" : `obstacle:${boundary.obstacleIndex}`;
  }

  private shouldUseDirectLaneTransfer(targetX: number, targetY: number): boolean {
    const pose = this.poseFusion.getCurrentPose();
    return !this.segmentIntersectsAnyObstacle(
      pose.position.xMeters,
      pose.position.yMeters,
      targetX,
      targetY,
    );
  }

  private async followDirectLaneTransfer(
    targetX: number,
    targetY: number,
    stripIndex: number,
    continuation: MowingResumeContinuation,
  ): Promise<{
    readonly completed: boolean;
    readonly reason: "reached_end" | "user_stopped" | "error";
    readonly error?: string;
  }> {
    this.persistResumeOperation({
      kind: "drive",
      phase: "following_connector",
      stripIndex,
      targetX,
      targetY,
      errorCode: "connector_failed",
      continuation,
    });
    if (this.isNearCurrentPose(targetX, targetY)) {
      return { completed: true, reason: "reached_end" };
    }

    const driveResult = await this.driveController.executeDrive({
      targetPosition: createPosition(targetX, targetY),
      learningEnabled: true,
    });
    if (driveResult.status === "success") {
      return { completed: true, reason: "reached_end" };
    }
    return {
      completed: false,
      reason: driveResult.status === "stopped" ? "user_stopped" : "error",
      error: driveResult.errorMessage,
    };
  }

  private isNearCurrentPose(x: number, y: number, toleranceMeters: number = MOWING_TARGET_REACHED_TOLERANCE_METERS): boolean {
    const pose = this.poseFusion.getCurrentPose();
    return Math.hypot(
      pose.position.xMeters - x,
      pose.position.yMeters - y,
    ) <= toleranceMeters;
  }

  private segmentIntersectsAnyObstacle(startX: number, startY: number, endX: number, endY: number): boolean {
    return this.obstaclePointsArray.some((obstacle) => segmentIntersectsPolygon(
      { x: startX, y: startY },
      { x: endX, y: endY },
      normalizePolygon(obstacle),
    ));
  }

  private reanchorPlanToCurrentPose(): void {
    if (this.plan.strips.length <= 1) {
      return;
    }

    const pose = this.poseFusion.getCurrentPose();
    const replanned = buildMowingPlan(
      [...this.areaPoints],
      {
        headingDeg: this.plan.headingDeg,
        stripSpacingMeters: this.plan.stripSpacingMeters,
        bladeWidthMeters: this.plan.bladeWidthMeters,
        mowingStandoffMeters: this.parameters.mowingStandoffMeters,
        preferredStartPoint: {
          xMeters: pose.position.xMeters,
          yMeters: pose.position.yMeters,
        },
        obstacles: this.obstaclePointsArray,
      },
    );

    if (replanned.stripCount !== this.plan.stripCount) {
      this.logger.warn("mowing.plan_reanchor_rejected", {
        originalStripCount: this.plan.stripCount,
        replannedStripCount: replanned.stripCount,
      });
      return;
    }

    this.plan = replanned;
    this.currentStripIndex = 0;
    this.logger.info("mowing.plan_reanchored", {
      stripCount: this.plan.stripCount,
      poseX: pose.position.xMeters,
      poseY: pose.position.yMeters,
      firstStripStartX: this.plan.strips[0]?.traversalReversed
        ? this.plan.strips[0].end.xMeters
        : this.plan.strips[0].start.xMeters,
      firstStripStartY: this.plan.strips[0]?.traversalReversed
        ? this.plan.strips[0].end.yMeters
        : this.plan.strips[0].start.yMeters,
    });
  }

  private prepareAreaStartAnchorPlan(): void {
    if (this.plan.strips.length === 0) {
      return;
    }

    const currentPose = this.poseFusion.getCurrentPose();
    const current = {
      x: currentPose.position.xMeters,
      y: currentPose.position.yMeters,
    };
    const areaPolygon = normalizePolygon(this.areaPoints);
    if (areaPolygon.length < 3) {
      return;
    }
    const obstaclePolygons = this.obstaclePointsArray
      .map((obstacle) => normalizePolygon(obstacle))
      .filter((obstacle) => obstacle.length >= 3);
    const currentInsideArea = pointInPolygon(current.x, current.y, this.areaPoints);

    let bestAnchor: AreaStartAnchorPlan | null = null;
    let bestDistanceMeters = Infinity;

    for (const strip of this.plan.strips) {
      const startCandidate = this.buildAreaStartAnchorCandidate(
        strip.startBoundary.kind === "area" ? strip.start : null,
        strip.startBoundary.kind === "area" ? strip.end : null,
        current,
        areaPolygon,
        obstaclePolygons,
        currentInsideArea,
      );
      if (startCandidate) {
        const distanceMeters = Math.hypot(
          startCandidate.entryPlan.approachTarget.xMeters - current.x,
          startCandidate.entryPlan.approachTarget.yMeters - current.y,
        );
        if (distanceMeters < bestDistanceMeters) {
          bestDistanceMeters = distanceMeters;
          bestAnchor = startCandidate;
        }
      }

      const endCandidate = this.buildAreaStartAnchorCandidate(
        strip.endBoundary.kind === "area" ? strip.end : null,
        strip.endBoundary.kind === "area" ? strip.start : null,
        current,
        areaPolygon,
        obstaclePolygons,
        currentInsideArea,
      );
      if (endCandidate) {
        const distanceMeters = Math.hypot(
          endCandidate.entryPlan.approachTarget.xMeters - current.x,
          endCandidate.entryPlan.approachTarget.yMeters - current.y,
        );
        if (distanceMeters < bestDistanceMeters) {
          bestDistanceMeters = distanceMeters;
          bestAnchor = endCandidate;
        }
      }
    }

    if (!bestAnchor) {
      this.logger.info("mowing.start_anchor.none_found", {
        strips: this.plan.strips.length,
      });
      return;
    }

    const anchoredPlan = buildMowingPlan([...this.areaPoints], {
      headingDeg: this.plan.headingDeg,
      stripSpacingMeters: this.plan.stripSpacingMeters,
      bladeWidthMeters: this.plan.bladeWidthMeters,
      mowingStandoffMeters: this.parameters.mowingStandoffMeters,
      preferredStartPoint: bestAnchor.preferredStartPoint,
      obstacles: this.obstaclePointsArray,
    });
    if (anchoredPlan.stripCount !== this.plan.stripCount || anchoredPlan.strips.length === 0) {
      this.logger.warn("mowing.start_anchor.replan_rejected", {
        originalStripCount: this.plan.stripCount,
        anchoredStripCount: anchoredPlan.stripCount,
      });
      return;
    }
    const anchoredFirstStrip = anchoredPlan.strips[0];
    const anchoredFirstStripStart = anchoredFirstStrip?.traversalReversed
      ? anchoredFirstStrip.end
      : anchoredFirstStrip?.start;
    if (!anchoredFirstStripStart || Math.hypot(
      anchoredFirstStripStart.xMeters - bestAnchor.preferredStartPoint.xMeters,
      anchoredFirstStripStart.yMeters - bestAnchor.preferredStartPoint.yMeters,
    ) > MOWING_TARGET_REACHED_TOLERANCE_METERS) {
      this.logger.warn("mowing.start_anchor.replan_start_mismatch", {
        preferredStartX: bestAnchor.preferredStartPoint.xMeters,
        preferredStartY: bestAnchor.preferredStartPoint.yMeters,
        anchoredStartX: anchoredFirstStripStart?.xMeters ?? null,
        anchoredStartY: anchoredFirstStripStart?.yMeters ?? null,
      });
      return;
    }

    this.plan = anchoredPlan;
    this.selectedAreaStartAnchor = bestAnchor;
    this.currentStripIndex = 0;
    this.logger.info("mowing.start_anchor.selected", {
      distanceMeters: bestDistanceMeters,
      entryX: bestAnchor.entryPlan.entryPoint.xMeters,
      entryY: bestAnchor.entryPlan.entryPoint.yMeters,
      approachX: bestAnchor.entryPlan.approachTarget.xMeters,
      approachY: bestAnchor.entryPlan.approachTarget.yMeters,
      firstStripStartX: anchoredPlan.strips[0]?.traversalReversed
        ? anchoredPlan.strips[0].end.xMeters
        : anchoredPlan.strips[0].start.xMeters,
      firstStripStartY: anchoredPlan.strips[0]?.traversalReversed
        ? anchoredPlan.strips[0].end.yMeters
        : anchoredPlan.strips[0].start.yMeters,
    });
  }

  private buildForcedInitialAreaTracePlan(
    boundaryKey: string,
    boundaryPoints: ReadonlyArray<PathPoint>,
    currentPose: ReturnType<PoseFusion["getCurrentPose"]>,
  ): { plan: ReturnType<typeof buildPerimeterJoinPlan>; orderedLoopPoints: PathPoint[]; anchorPoint: PathPoint; boundaryPoints: PathPoint[] } | null {
    if (boundaryKey !== "area" || this.tracedBoundaries.has("area") || !this.selectedAreaStartAnchor) {
      return null;
    }

    const anchorPoint = this.selectedAreaStartAnchor.entryPlan.entryPoint;
    const anchoredBoundaryPoints = insertPreferredBoundaryPoint(boundaryPoints, anchorPoint);
    const anchorPose = {
      ...currentPose,
      position: createPosition(anchorPoint.xMeters, anchorPoint.yMeters),
    };
    const plan = buildPerimeterJoinPlan(anchoredBoundaryPoints, anchorPose, this.parameters);
    if (!plan) {
      return null;
    }

    const orderedLoopPoints = buildPerimeterPathPointsFromPlan(anchoredBoundaryPoints, plan, this.parameters);
    if (orderedLoopPoints.length < 2) {
      return null;
    }

    return {
      plan,
      orderedLoopPoints,
      anchorPoint,
      boundaryPoints: anchoredBoundaryPoints,
    };
  }

  private buildAreaStartAnchorCandidate(
    perimeterPoint: PathPoint | null,
    oppositePoint: PathPoint | null,
    current: { x: number; y: number },
    areaPolygon: Array<{ x: number; y: number }>,
    obstaclePolygons: Array<Array<{ x: number; y: number }>>,
    currentInsideArea: boolean,
  ): AreaStartAnchorPlan | null {
    if (!perimeterPoint || !oppositePoint) {
      return null;
    }

    const stripVector = {
      x: oppositePoint.xMeters - perimeterPoint.xMeters,
      y: oppositePoint.yMeters - perimeterPoint.yMeters,
    };
    const stripLength = Math.hypot(stripVector.x, stripVector.y);
    if (stripLength <= 1e-6) {
      return null;
    }

    const approachTarget = {
      xMeters: perimeterPoint.xMeters + ((stripVector.x / stripLength) * this.standoff),
      yMeters: perimeterPoint.yMeters + ((stripVector.y / stripLength) * this.standoff),
    };
    if (!pointInPolygon(approachTarget.xMeters, approachTarget.yMeters, this.areaPoints)) {
      return null;
    }
    if (!this.isAreaStartAnchorReachable(
      current,
      approachTarget,
      obstaclePolygons,
      currentInsideArea,
    )) {
      return null;
    }

    return {
      preferredStartPoint: {
        xMeters: perimeterPoint.xMeters,
        yMeters: perimeterPoint.yMeters,
      },
      entryPlan: {
        entryPoint: {
          xMeters: perimeterPoint.xMeters,
          yMeters: perimeterPoint.yMeters,
          capturedAt: perimeterPoint.capturedAt,
        },
        approachTarget,
        segmentIndex: nearestAreaSegmentIndex(areaPolygon, {
          x: perimeterPoint.xMeters,
          y: perimeterPoint.yMeters,
        }),
        distanceMeters: Math.hypot(
          approachTarget.xMeters - current.x,
          approachTarget.yMeters - current.y,
        ),
        tangentHeadingDeg: Math.atan2(stripVector.y, stripVector.x) * (180 / Math.PI),
      },
    };
  }

  private isAreaStartAnchorReachable(
    current: { x: number; y: number },
    target: { xMeters: number; yMeters: number },
    obstaclePolygons: Array<Array<{ x: number; y: number }>>,
    currentInsideArea: boolean,
  ): boolean {
    const start = { x: current.x, y: current.y };
    const end = { x: target.xMeters, y: target.yMeters };
    if (obstaclePolygons.some((obstacle) => segmentIntersectsPolygon(start, end, obstacle))) {
      return false;
    }

    let hasEnteredArea = currentInsideArea;
    const sampleCount = 40;
    for (let index = 1; index <= sampleCount; index += 1) {
      const t = index / sampleCount;
      const sample = {
        x: start.x + ((end.x - start.x) * t),
        y: start.y + ((end.y - start.y) * t),
      };
      const inside = pointInPolygon(sample.x, sample.y, this.areaPoints);
      if (inside) {
        hasEnteredArea = true;
        continue;
      }
      if (hasEnteredArea) {
        return false;
      }
    }

    return !currentInsideArea || pointInPolygon(midpoint(start, end).x, midpoint(start, end).y, this.areaPoints) || hasEnteredArea;
  }

  private getBoundaryPoints(key: string): ReadonlyArray<PathPoint> {
    if (key === "area") {
      return [...this.areaPoints];
    }
    const match = key.match(/^obstacle:(\d+)$/);
    if (match) {
      const idx = parseInt(match[1], 10);
      return this.obstaclePointsArray[idx] ?? [];
    }
    return [];
  }

  private startAreaEscapeMonitor(): void {
    if (this.areaEscapeMonitor) {
      clearInterval(this.areaEscapeMonitor);
    }
    this.areaEscapeMonitor = setInterval(() => {
      if (this.outsideAreaViolationMessage || this.stopRequested || systemStop.isStopped()) {
        return;
      }
      const pose = this.poseFusion.getCurrentPose();
      const outsideDistanceMeters = outsideDistanceFromAreaMeters(
        pose.position.xMeters,
        pose.position.yMeters,
        this.areaPoints,
      );
      if (outsideDistanceMeters <= AREA_ESCAPE_STOP_DISTANCE_METERS) {
        return;
      }
      this.outsideAreaViolationMessage = `outside_mowing_area:${outsideDistanceMeters.toFixed(2)}m`;
      this.logger.warn("mowing.outside_area_limit_exceeded", {
        xMeters: pose.position.xMeters,
        yMeters: pose.position.yMeters,
        outsideDistanceMeters,
        limitMeters: AREA_ESCAPE_STOP_DISTANCE_METERS,
      });
      systemStop.requestStop("mowing", "outside_mowing_area_limit_exceeded");
    }, AREA_ESCAPE_CHECK_INTERVAL_MS);
    this.areaEscapeMonitor.unref?.();
  }

  private stopAreaEscapeMonitor(): void {
    if (!this.areaEscapeMonitor) {
      return;
    }
    clearInterval(this.areaEscapeMonitor);
    this.areaEscapeMonitor = null;
  }

  private buildOutsideAreaStatus(): MowingStatus | null {
    if (!this.outsideAreaViolationMessage) {
      return null;
    }
    this.phase = "error";
    return { ...this.getStatus(), error: this.outsideAreaViolationMessage };
  }

  private isStopped(): boolean {
    return this.stopRequested || systemStop.isStopped();
  }
}

function normalise(v: { x: number; y: number }): { x: number; y: number } {
  const len = Math.hypot(v.x, v.y);
  return len < 1e-9 ? { x: 1, y: 0 } : { x: v.x / len, y: v.y / len };
}

function offsetPoint(p: PathPoint, dir: { x: number; y: number }, distance: number): { x: number; y: number } {
  return { x: p.xMeters + dir.x * distance, y: p.yMeters + dir.y * distance };
}

function midpoint(a: { x: number; y: number }, b: { x: number; y: number }): { x: number; y: number } {
  return {
    x: (a.x + b.x) / 2,
    y: (a.y + b.y) / 2,
  };
}

function pointToPathDistance(point: PathPoint, path: ReadonlyArray<PathPoint>): number {
  let nearest = Infinity;
  for (const p of path) {
    const d = Math.hypot(p.xMeters - point.xMeters, p.yMeters - point.yMeters);
    if (d < nearest) {
      nearest = d;
    }
  }
  return nearest;
}

function insertPreferredBoundaryPoint(boundaryPoints: ReadonlyArray<PathPoint>, preferredPoint: PathPoint): PathPoint[] {
  if (boundaryPoints.length < 2) {
    return boundaryPoints.slice();
  }

  const points = boundaryPoints.slice();
  const first = points[0];
  const last = points[points.length - 1];
  const wasClosed = Math.hypot(first.xMeters - last.xMeters, first.yMeters - last.yMeters) <= PREFERRED_BOUNDARY_POINT_TOLERANCE_METERS;
  if (wasClosed) {
    points.pop();
  }

  if (points.some((point) => Math.hypot(point.xMeters - preferredPoint.xMeters, point.yMeters - preferredPoint.yMeters) <= PREFERRED_BOUNDARY_POINT_TOLERANCE_METERS)) {
    return wasClosed ? points.concat([points[0]]) : points;
  }

  let nearestSegmentIndex = 0;
  let nearestDistance = Infinity;
  const segmentCount = wasClosed ? points.length : points.length - 1;
  for (let index = 0; index < segmentCount; index += 1) {
    const current = points[index];
    const next = points[(index + 1) % points.length];
    const distance = pointToSegmentDistance(preferredPoint, current, next);
    if (distance < nearestDistance) {
      nearestDistance = distance;
      nearestSegmentIndex = index;
    }
  }

  points.splice(nearestSegmentIndex + 1, 0, preferredPoint);
  return wasClosed ? points.concat([points[0]]) : points;
}

function pointToSegmentDistance(point: PathPoint, start: PathPoint, end: PathPoint): number {
  const segmentX = end.xMeters - start.xMeters;
  const segmentY = end.yMeters - start.yMeters;
  const lengthSquared = (segmentX * segmentX) + (segmentY * segmentY);
  if (lengthSquared <= 1e-9) {
    return Math.hypot(point.xMeters - start.xMeters, point.yMeters - start.yMeters);
  }

  const t = Math.max(0, Math.min(1, (((point.xMeters - start.xMeters) * segmentX) + ((point.yMeters - start.yMeters) * segmentY)) / lengthSquared));
  const projectedX = start.xMeters + (segmentX * t);
  const projectedY = start.yMeters + (segmentY * t);
  return Math.hypot(point.xMeters - projectedX, point.yMeters - projectedY);
}

function normalizeSignedDegrees(angleDeg: number): number {
  let normalized = ((angleDeg + 180) % 360 + 360) % 360 - 180;
  if (normalized === -180) {
    normalized = 180;
  }
  return normalized;
}

function normalizePolygon(points: ReadonlyArray<PathPoint>): Array<{ x: number; y: number }> {
  if (points.length === 0) {
    return [];
  }
  const polygon = points.map((point) => ({ x: point.xMeters, y: point.yMeters }));
  const first = polygon[0];
  const last = polygon[polygon.length - 1];
  if (Math.hypot(first.x - last.x, first.y - last.y) <= 1e-9) {
    polygon.pop();
  }
  return polygon;
}

function nearestAreaSegmentIndex(
  polygon: ReadonlyArray<{ x: number; y: number }>,
  point: { x: number; y: number },
): number {
  if (polygon.length < 2) {
    return 0;
  }

  let bestIndex = 0;
  let bestDistance = Infinity;
  for (let index = 0; index < polygon.length; index += 1) {
    const start = polygon[index];
    const end = polygon[(index + 1) % polygon.length];
    const projection = nearestPointOnSegment(point, start, end);
    const distance = Math.hypot(point.x - projection.x, point.y - projection.y);
    if (distance < bestDistance) {
      bestDistance = distance;
      bestIndex = index;
    }
  }
  return bestIndex;
}

function nearestPointOnSegment(
  point: { x: number; y: number },
  start: { x: number; y: number },
  end: { x: number; y: number },
): { x: number; y: number } {
  const dx = end.x - start.x;
  const dy = end.y - start.y;
  const lengthSquared = (dx * dx) + (dy * dy);
  if (lengthSquared <= 1e-12) {
    return start;
  }
  const t = Math.max(0, Math.min(1, (((point.x - start.x) * dx) + ((point.y - start.y) * dy)) / lengthSquared));
  return {
    x: start.x + (dx * t),
    y: start.y + (dy * t),
  };
}

function pointInPolygon(x: number, y: number, polygonPoints: ReadonlyArray<PathPoint>): boolean {
  const polygon = normalizePolygon(polygonPoints);
  if (polygon.length < 3) {
    return false;
  }

  let inside = false;
  for (let index = 0, previous = polygon.length - 1; index < polygon.length; previous = index, index += 1) {
    const current = polygon[index];
    const prior = polygon[previous];
    const intersects = ((current.y > y) !== (prior.y > y))
      && (x < (((prior.x - current.x) * (y - current.y)) / ((prior.y - current.y) || 1e-12)) + current.x);
    if (intersects) {
      inside = !inside;
    }
  }
  return inside;
}

function outsideDistanceFromAreaMeters(x: number, y: number, polygonPoints: ReadonlyArray<PathPoint>): number {
  if (pointInPolygon(x, y, polygonPoints)) {
    return 0;
  }

  const polygon = normalizePolygon(polygonPoints);
  if (polygon.length < 2) {
    return Infinity;
  }

  let nearest = Infinity;
  for (let index = 0; index < polygon.length; index += 1) {
    const start = polygon[index];
    const end = polygon[(index + 1) % polygon.length];
    nearest = Math.min(nearest, pointToSegmentDistanceMeters(x, y, start.x, start.y, end.x, end.y));
  }
  return nearest;
}

function movePointInsideArea(
  entryPoint: PathPoint,
  approachTarget: { xMeters: number; yMeters: number },
  polygonPoints: ReadonlyArray<PathPoint>,
  preferredInsetMeters: number,
): { x: number; y: number } {
  const dx = approachTarget.xMeters - entryPoint.xMeters;
  const dy = approachTarget.yMeters - entryPoint.yMeters;
  const length = Math.hypot(dx, dy);
  if (length <= 1e-9) {
    return { x: entryPoint.xMeters, y: entryPoint.yMeters };
  }

  const inset = Math.max(0.02, preferredInsetMeters);
  const candidate = {
    x: entryPoint.xMeters - ((dx / length) * inset),
    y: entryPoint.yMeters - ((dy / length) * inset),
  };
  if (pointInPolygon(candidate.x, candidate.y, polygonPoints)) {
    return candidate;
  }

  for (let scale = 1.5; scale <= 4; scale += 0.5) {
    const retried = {
      x: entryPoint.xMeters - ((dx / length) * inset * scale),
      y: entryPoint.yMeters - ((dy / length) * inset * scale),
    };
    if (pointInPolygon(retried.x, retried.y, polygonPoints)) {
      return retried;
    }
  }

  return { x: entryPoint.xMeters, y: entryPoint.yMeters };
}

function pointToSegmentDistanceMeters(
  x: number,
  y: number,
  startX: number,
  startY: number,
  endX: number,
  endY: number,
): number {
  const segmentX = endX - startX;
  const segmentY = endY - startY;
  const lengthSquared = (segmentX * segmentX) + (segmentY * segmentY);
  if (lengthSquared <= 1e-12) {
    return Math.hypot(x - startX, y - startY);
  }

  const t = Math.max(0, Math.min(1, (((x - startX) * segmentX) + ((y - startY) * segmentY)) / lengthSquared));
  const projectedX = startX + (segmentX * t);
  const projectedY = startY + (segmentY * t);
  return Math.hypot(x - projectedX, y - projectedY);
}

function segmentIntersectsPolygon(
  start: { x: number; y: number },
  end: { x: number; y: number },
  polygon: ReadonlyArray<{ x: number; y: number }>,
): boolean {
  if (polygon.length < 2) {
    return false;
  }
  for (let index = 0; index < polygon.length; index += 1) {
    const current = polygon[index];
    const next = polygon[(index + 1) % polygon.length];
    if (segmentsIntersect(start, end, current, next)) {
      return true;
    }
  }
  return false;
}

function segmentsIntersect(
  aStart: { x: number; y: number },
  aEnd: { x: number; y: number },
  bStart: { x: number; y: number },
  bEnd: { x: number; y: number },
): boolean {
  const o1 = orientation(aStart, aEnd, bStart);
  const o2 = orientation(aStart, aEnd, bEnd);
  const o3 = orientation(bStart, bEnd, aStart);
  const o4 = orientation(bStart, bEnd, aEnd);

  if (o1 !== o2 && o3 !== o4) {
    return true;
  }
  if (o1 === 0 && onSegment(aStart, bStart, aEnd)) {
    return true;
  }
  if (o2 === 0 && onSegment(aStart, bEnd, aEnd)) {
    return true;
  }
  if (o3 === 0 && onSegment(bStart, aStart, bEnd)) {
    return true;
  }
  if (o4 === 0 && onSegment(bStart, aEnd, bEnd)) {
    return true;
  }
  return false;
}

function orientation(
  a: { x: number; y: number },
  b: { x: number; y: number },
  c: { x: number; y: number },
): number {
  const value = ((b.y - a.y) * (c.x - b.x)) - ((b.x - a.x) * (c.y - b.y));
  if (Math.abs(value) <= 1e-9) {
    return 0;
  }
  return value > 0 ? 1 : 2;
}

function onSegment(
  start: { x: number; y: number },
  point: { x: number; y: number },
  end: { x: number; y: number },
): boolean {
  return point.x <= Math.max(start.x, end.x) + 1e-9
    && point.x + 1e-9 >= Math.min(start.x, end.x)
    && point.y <= Math.max(start.y, end.y) + 1e-9
    && point.y + 1e-9 >= Math.min(start.y, end.y);
}
